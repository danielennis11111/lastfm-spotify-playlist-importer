#!/bin/bash
set -e

# Configuration
PROJECT_ID="true-shuffle-radio"
SERVICE_NAME="lastfm-spotify-converter"
REGION="us-central1"
MAX_INSTANCES=10
MEMORY="512Mi"
CPU=1
TIMEOUT="10m"

# Get the current Git commit hash for versioning
COMMIT_HASH=$(git rev-parse --short HEAD 2>/dev/null || echo "latest")
IMAGE_NAME="gcr.io/${PROJECT_ID}/${SERVICE_NAME}:${COMMIT_HASH}"

echo "🚀 Deploying to Google Cloud Run..."
echo "Project: ${PROJECT_ID}"
echo "Service: ${SERVICE_NAME}"
echo "Region: ${REGION}"
echo "Image: ${IMAGE_NAME}"

# Ensure gcloud is configured for the correct project
echo "📝 Setting Google Cloud project..."
gcloud config set project ${PROJECT_ID}

# Build the container image
echo "🏗️ Building container image..."
gcloud builds submit --tag ${IMAGE_NAME}

# Deploy to Cloud Run
echo "🚀 Deploying to Cloud Run..."
gcloud run deploy ${SERVICE_NAME} \
  --image ${IMAGE_NAME} \
  --platform managed \
  --region ${REGION} \
  --allow-unauthenticated \
  --memory ${MEMORY} \
  --cpu ${CPU} \
  --timeout ${TIMEOUT} \
  --max-instances ${MAX_INSTANCES} \
  --set-env-vars="ENVIRONMENT=production" \
  --update-secrets="SPOTIFY_CLIENT_ID=SPOTIFY_CLIENT_ID:latest,SPOTIFY_CLIENT_SECRET=SPOTIFY_CLIENT_SECRET:latest,LASTFM_API_KEY=LASTFM_API_KEY:latest,FLASK_SECRET_KEY=flask-secret-key:latest,SPOTIFY_REDIRECT_URI=SPOTIFY_REDIRECT_URI:latest"

# Get the service URL
SERVICE_URL=$(gcloud run services describe ${SERVICE_NAME} --platform managed --region ${REGION} --format 'value(status.url)')
echo "✅ Deployment complete!"
echo "🔗 Service URL: ${SERVICE_URL}"
echo ""
echo "⚠️ IMPORTANT: Make sure your Spotify Developer Dashboard has this redirect URI:"
echo "${SERVICE_URL}/callback"
echo ""
echo "Updating the SERVICE_URL environment variable:"
gcloud run services update ${SERVICE_NAME} --platform managed --region ${REGION} --set-env-vars="SERVICE_URL=${SERVICE_URL}"
echo "✅ SERVICE_URL updated to: ${SERVICE_URL}" 