#!/bin/bash
set -e

# Configuration variables
PROJECT_ID="true-shuffle-radio"
REGION="us-central1"
SERVICE_NAME="lastfm-spotify-converter"
SERVICE_URL="https://lastfm-spotify-converter-service-url.a.run.app" # Replace with actual Cloud Run URL after first deployment
REDIRECT_URL_PATH="/callback"

# Build the Docker image
echo "Building Docker image..."
docker build -t "gcr.io/$PROJECT_ID/$SERVICE_NAME" .

# Push the image to Google Container Registry
echo "Pushing image to Google Container Registry..."
docker push "gcr.io/$PROJECT_ID/$SERVICE_NAME"

# Deploy to Cloud Run
echo "Deploying to Cloud Run..."
gcloud run deploy $SERVICE_NAME \
  --image "gcr.io/$PROJECT_ID/$SERVICE_NAME" \
  --platform managed \
  --region $REGION \
  --project $PROJECT_ID \
  --allow-unauthenticated \
  --update-secrets=LASTFM_API_KEY=lastfm-api-key:latest,SPOTIFY_CLIENT_ID=spotify-client-id:latest,SPOTIFY_CLIENT_SECRET=spotify-client-secret:latest,FLASK_SECRET_KEY=flask-secret-key:latest \
  --set-env-vars=ENVIRONMENT=production,SERVICE_URL=$SERVICE_URL,APP_BASE_PATH="/lastfm-to-spotify-importer"

# Get the deployed service URL
DEPLOYED_URL=$(gcloud run services describe $SERVICE_NAME --platform managed --region $REGION --project $PROJECT_ID --format 'value(status.url)')
echo "Service deployed to: $DEPLOYED_URL"

# If this is the first deployment, you need to update SERVICE_URL in this script and in Cloud Run
if [ "$SERVICE_URL" = "https://lastfm-spotify-converter-service-url.a.run.app" ]; then
  echo "IMPORTANT: This appears to be the first deployment."
  echo "Please update the SERVICE_URL in this script to: $DEPLOYED_URL"
  echo "Then update the Cloud Run service environment variables:"
  echo ""
  echo "gcloud run services update $SERVICE_NAME \\"
  echo "  --platform managed \\"
  echo "  --region $REGION \\"
  echo "  --project $PROJECT_ID \\"
  echo "  --set-env-vars=\"SERVICE_URL=$DEPLOYED_URL\""
  echo ""
  echo "Finally, update your Spotify Developer Dashboard to use this redirect URI:"
  echo "$DEPLOYED_URL/callback"
fi

echo ""
echo "DEPLOYMENT COMPLETE!"
echo ""
echo "IMPORTANT NEXT STEPS:"
echo "1. Create an index.html file for vibe-coding.rocks with the Cloud Run URL: $DEPLOYED_URL"
echo "2. Upload the index.html to vibe-coding.rocks/lastfm-to-spotify-importer/"
echo "3. Make sure your Spotify Developer Dashboard has these redirect URIs:"
echo "   - $DEPLOYED_URL/callback (for direct access)"
echo "   - https://vibe-coding.rocks/lastfm-to-spotify-importer/callback (for embedded access)"
echo "" 